<?php
include("conexion.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_usuario'])) {
    $id_usuario = intval($_POST['id_usuario']);

    // Eliminar alquileres relacionados
    $conn->query("DELETE FROM alquileres WHERE id_usuario = $id_usuario");

    // Eliminar usuario
    $conn->query("DELETE FROM usuarios WHERE id_usuario = $id_usuario");

    echo "Usuario eliminado correctamente.";
}
?>
