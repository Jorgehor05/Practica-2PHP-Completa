<?php
include("conexion.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_coche'])) {
    $id_coche = intval($_POST['id_coche']);

    // Eliminar alquileres relacionados
    $conn->query("DELETE FROM alquileres WHERE id_coche = $id_coche");

    // Eliminar coche
    $conn->query("DELETE FROM coches WHERE id_coche = $id_coche");

    echo "Coche eliminado correctamente.";
}
?>
