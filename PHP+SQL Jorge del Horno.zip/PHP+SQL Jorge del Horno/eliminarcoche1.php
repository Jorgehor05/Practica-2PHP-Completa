<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP+SQL</title>
    <style>
          body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #2c2c2c; /* Fondo gris oscuro */
    color: #f4f4f9; /* Texto claro */
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    text-align: center;
    position: relative;
}
body::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6); /* Oscurece un poco el fondo */
    z-index: -1;
}

h1 {
    font-size: 2.5rem;
    color: #fff;
    margin-bottom: 20px;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 1px;
    padding: 10px;
    background-color: #444; /* Fondo más oscuro */
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
}


h2 {
    font-size: 1.5rem;
    color: #f4f4f9;
    margin-bottom: 15px;
    text-transform: uppercase;
    font-weight: 600;
}


form {
    background-color: #3c3c3c; /* Fondo oscuro para el formulario */
    padding: 20px;
    border-radius: 8px;
	 border: 2px solid red;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
    max-width: 400px;
    width: 90%;
    color: #fff; /* Texto claro */
}


select {
    width: 100%;
    padding: 10px;
    font-size: 1rem;
    border: 1px solid #666; /* Borde gris intermedio */
    border-radius: 5px;
    box-sizing: border-box;
    margin-bottom: 15px;
    background-color: #555; /* Fondo gris oscuro */
    color: #f4f4f9; /* Texto claro */
    cursor: pointer;
    transition: all 0.3s ease-in-out;
}


select:focus {
    border-color: #f4f4f9;
    outline: none;
    background-color: #666; /* Fondo ligeramente más claro al enfoque */
}


select option:hover {
    background-color: #444;
    color: #fff;
}


form:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.6);
    transform: scale(1.02);
    transition: all 0.3s ease-in-out;
}
    </style>
</head>
<body>

    <section id="coches">
        <form action="eliminarcoche2.php" method="post">
		<h2>Eliminar Coches</h2>
            <label for="id_coche">Selecciona un coche:</label>
            <select name="id_coche" id="id_coche">
			<option value="" disabled selected></option>

                <?php
                include("conexion.php");
                $result = $conn->query("SELECT id_coche, modelo, marca FROM coches");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id_coche']}'>{$row['marca']} - {$row['modelo']}</option>";
                }
                ?>
            </select>
            <button type="submit">Eliminar Coche</button>
        </form>
    </section>


</body>
</html>
