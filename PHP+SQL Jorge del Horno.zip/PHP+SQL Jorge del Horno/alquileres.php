<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP+SQL</title>
    <script>
        function redirigirPagina(selectElement) {
            const url = selectElement.value; // Obtiene el valor seleccionado
            if (url) {
                window.location.href = url; // Redirige a la URL
            }
        }
    </script>
	<link rel="stylesheet" href="coches.css">
</head>
<body>
    <form action="coches/añadirCoche.php" method="post">
        <h2>Gestión de Alquileres</h2>
        <select name="accion" onchange="redirigirPagina(this)">
			<option value="" disabled selected></option>

            <option value="listaralquiler.php">Listar alquiler</option>
			<br>
			<br>
            <option value="eliminaralquiler1.php">Eliminar alquiler</option>
        </select>
    </form>

</body>
</html>