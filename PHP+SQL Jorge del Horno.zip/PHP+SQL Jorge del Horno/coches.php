<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP+SQL</title>
    <script>
        function redirigirPagina(selectElement) {
            const url = selectElement.value; // Obtiene el valor seleccionado
            if (url) {
                window.location.href = url; // Redirige a la URL
            }
        }
    </script>
	<link rel="stylesheet" href="coches.css">
</head>
<body>
    <form action="coches/añadirCoche.php" method="post">
        <h2>Gestión de Coches</h2>
        <select name="accion" onchange="redirigirPagina(this)">
			<option value="" disabled selected></option>
            <option value="añadircoche1.php"> Añadir Coche</option>
            <option value="listarcoche.php">Listar Coches</option>
            <option value="buscarcoche1.php">Buscar Coches</option>
            <option value="modificarcoche1.php"> Modificar Coche </option>
            <option value="eliminarcoche1.php">Eliminar Coche</option>
        </select>
    </form>

</body>
</html>