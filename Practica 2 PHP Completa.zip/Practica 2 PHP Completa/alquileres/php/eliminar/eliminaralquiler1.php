<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP+SQL</title>
    <style>
          body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #2c2c2c; /* Fondo gris oscuro */
    color: #f4f4f9; /* Texto claro */
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    text-align: center;
    position: relative;
}
body::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6); /* Oscurece un poco el fondo */
    z-index: -1;
}

h1 {
    font-size: 2.5rem;
    color: #fff;
    margin-bottom: 20px;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 1px;
    padding: 10px;
    background-color: #444; /* Fondo más oscuro */
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
}


h2 {
    font-size: 1.5rem;
    color: #f4f4f9;
    margin-bottom: 15px;
    text-transform: uppercase;
    font-weight: 600;
}


form {
    background-color: #3c3c3c; /* Fondo oscuro para el formulario */
    padding: 20px;
    border-radius: 8px;
	 border: 2px solid red;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
    max-width: 400px;
    width: 90%;
    color: #fff; /* Texto claro */
}


select {
    width: 100%;
    padding: 10px;
    font-size: 1rem;
    border: 1px solid #666; /* Borde gris intermedio */
    border-radius: 5px;
    box-sizing: border-box;
    margin-bottom: 15px;
    background-color: #555; /* Fondo gris oscuro */
    color: #f4f4f9; /* Texto claro */
    cursor: pointer;
    transition: all 0.3s ease-in-out;
}


select:focus {
    border-color: #f4f4f9;
    outline: none;
    background-color: #666; /* Fondo ligeramente más claro al enfoque */
}


select option:hover {
    background-color: #444;
    color: #fff;
}


form:hover {
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.6);
    transform: scale(1.02);
    transition: all 0.3s ease-in-out;
}
    </style>
</head>
<body>
    <section id="alquileres">
        <h2>Eliminar Alquileres</h2>
    <form action="eliminarcoche2.php" method="post">
        <label for="id_coche">ID del Coche:</label>
        <input type="number" name="id_coche" id="id_coche" required>
        <input type="submit" value="Eliminar Alquiler">
    </form>
    </section>
<br>
<br>
<?PHP

// Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "rootroot", "coches")
    or die("No se pudo conectar a la base de datos");

// Consulta para obtener todos los registros de la tabla `alquileres`
$query = "SELECT a.id_alquiler, a.id_usuario, 
                 a.id_coche, c.modelo AS modelo_coche, c.marca AS marca_coche, 
                 a.prestado, a.devuelto 
          FROM alquileres a
          LEFT JOIN usuarios u ON a.id_usuario = u.id_usuario
          LEFT JOIN coches c ON a.id_coche = c.id_coche";

$result = mysqli_query($conexion, $query) or die("Error en la consulta: " . mysqli_error($conexion));

// Verificar si hay resultados
if (mysqli_num_rows($result) > 0) {
    echo "<h3>Lista de Alquileres</h3>";
    echo "<table cellpadding='8'>";
    echo "<thead>
            <tr>
                <th>ID Alquiler</th>
                <th>ID Usuario</th>
                <th>ID Coche</th>
                <th>Modelo Coche</th>
                <th>Marca Coche</th>
                <th>Prestado</th>
                <th>Devuelto</th>
            </tr>
          </thead>";
    echo "<tbody>";

    // Mostrar cada fila de resultados
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['id_alquiler'] . "</td>";
        echo "<td>" . $row['id_usuario'] . "</td>";
        echo "<td>" . $row['id_coche'] . "</td>";
        echo "<td>" . $row['modelo_coche'] . "</td>";
        echo "<td>" . $row['marca_coche'] . "</td>";
        echo "<td>" . $row['prestado'] . "</td>";
        echo "<td>" . ($row['devuelto'] ? $row['devuelto'] : "Pendiente") . "</td>";
        echo "</tr>";
    }

    echo "</tbody>";
    echo "</table>";
} else {
    echo "<h1>No hay alquileres registrados</h1>";
}

// Cerrar la conexión
mysqli_close($conexion);
?>

</body>
</html>

