<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Coches</title>
    <link rel="stylesheet" href="buscar1.css">
</head>
<body>
<header>
        <h1>Concesionario Hornos</h1>
    </header>
    <nav>
        <ul>
            <li><a href="index.html">Inicio</a></li>
            <li><a href="coches.html">Coches</a></li>
            <li><a href="alquiler.html">Alquilar</a></li>
            <li><a href="login.html">Iniciar Sesión</a></li>
        </ul>
    </nav>
	<br>
    <div class="container">
        <h1>Buscar Coches</h1>
        <form action="buscar2.php" method="post">
            <label for="marca">Marca:</label>
            <input type="text" id="marca" name="marca" placeholder="Buscar por marca...">
            
            <label for="modelo">Modelo:</label>
            <input type="text" id="modelo" name="modelo" placeholder="Buscar por modelo...">
            
            <label for="color">Color:</label>
            <input type="text" id="color" name="color" placeholder="Buscar por color...">
			
			<label for="color"> Precio máximo:</label>
            <input type="number" id="precio" name="precio" placeholder="Buscar por precio máximo...">
            
            <input type="submit" value="Buscar">
        </form>
    </div>
	
	<section class="descripcion">
	<h2 class="dosh2">Servicios Hornos </h2>
	<p class="dosp"> Más de 20 años han hecho de Hornos, el concesionario segunda mano líder en compraventa de vehículos en España. Queremos ofrecerte la mejor opción a la hora de vender o comprar tu coche de ocasión. </a>
	<br>
	<br>
	<p class="dosp"> <a class="azul1">Ventajas de comprar un coche de segunda mano</a>
	<br>
	<br>
Nuestros clientes compran coches de segunda mano porque estos tienen un precio menor que los nuevos, eso es un hecho. La ventaja de hacerlo en Canalcar es que no estás obligado a renunciar a la calidad o a la garantía por este motivo, ni siquiera en coches más básicos. Además, los coches de ocasión se presentan como una oportunidad única para adquirir gama Premium, ya que la calidad de fabricación de este tipo de coches usados los hace conservarse en un perfecto estado –permitiéndote la compra de un coche prácticamente nuevo a un precio mucho menor.<br>
<br>
<br>
<a class="azul1"> Coches de ocasión con garantía </a>
<br>
<br>
En Hornos tenemos los coches de segunda mano con mayor calidad, ya que nuestros vehículos pasan el más riguroso control de calidad de 110 puntos –solo lo supera 1 de cada 4 coches–. Estamos tan seguros de la calidad de nuestros coches de segunda mano que le ofrecemos una Garantía 5 Estrellas muy similar a la de los coches nuevos.<br>
<br>
<br>
<a class="azul1"> Concesionario de ocasión multimarca </a>
<br>
<br>	
En Hornos, el concesionario de coches de ocasión más grande de Madrid, disponemos de una gran variedad de marcas y modelos. Encuentra el vehículo de segunda mano que mejor se adapte a tus necesidades, con la mejor relación calidad-precio. O si lo prefieres, ven a vernos y te aconsejamos.
	<br>
	<br>
	<br>
	<br>
	<br>
</section>
	<section class="pie">
	<div class="pie">
	</div>
	</section>
	
	
	
	
	
	
	
	
	
	
</body>
</html>

